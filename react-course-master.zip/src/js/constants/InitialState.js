export default ({
    posts: []
});