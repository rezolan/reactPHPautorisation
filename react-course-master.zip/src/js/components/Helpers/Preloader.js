import React from 'react';
// import '../../sass'

const Preloader =  props => (
  <div id="preloader"></div>
);

export default Preloader;